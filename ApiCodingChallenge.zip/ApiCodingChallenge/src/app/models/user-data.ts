export class UserData {
    uid: number;
  name: string;
  email: string;
  password: string;
  roles: string;

}
